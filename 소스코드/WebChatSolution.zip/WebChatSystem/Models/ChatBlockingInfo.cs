﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatSystem.Models
{
    /// <summary>
    /// 채팅 블로킹 정보 모델
    /// </summary>
    public class ChatBlockingInfo
    {
        public string RoomName { get; set; }
        public List<BlockingUserInfo> NickNames { get; set; }
    }

}