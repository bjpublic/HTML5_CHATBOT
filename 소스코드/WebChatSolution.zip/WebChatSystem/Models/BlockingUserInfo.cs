﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatSystem.Models
{
    //채팅 블로킹 사용자정보 모델
    public class BlockingUserInfo
    {
        public string RoomName { get; set; }
        public string NickName { get; set; }
        public string BlockingType { get; set; }

    }

}