﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatSystem.Models
{
    /// <summary>
    /// 채팅 사용자 데이터 모델
    /// </summary>
    public class ChatUserModel
    {
        /// <summary>
        /// 채팅방명
        /// </summary>
        public string ChatRoomName { get; set; }

        /// <summary>
        /// 커넥션아이디
        /// </summary>
        public string ConnectionID { get; set; }

        /// <summary>
        /// 대화명
        /// </summary>
        public string NickName { get; set; }

        /// <summary>
        /// 접속IP주소
        /// </summary>
        public string IPAddress { get; set; }

        /// <summary>
        /// 연결일시
        /// </summary>
        public DateTime ConnectedDate { get; set; }
    }

}