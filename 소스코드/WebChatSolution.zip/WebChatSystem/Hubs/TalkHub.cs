﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;

using System.Threading.Tasks;
using WebChatSystem.Models;
using Newtonsoft.Json;

using WebChatSystem.Data;

namespace WebChatSystem.Hubs
{
    public class TalkHub : Hub
    {

        private eddywebchatbotdbEntities db = new eddywebchatbotdbEntities();


        public void Hello()
        {
            Clients.All.hello();
        }

        /// <summary>
        /// 사용자 대화방 입장 및 입장 알림 브로드캐스팅
        /// </summary>
        /// <param name="userName"></param>
        public void Entry(string userName)
        {
            string entryMsg = string.Format("{0}님이 입장하셨습니다.", userName);
            Clients.All.EntryMessage(entryMsg);
        }


        /// <summary>
        /// 채팅 메시지 수신 및 브로드 캐스팅
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="message"></param>
        public void Send(string userName, string message)
        {
            message = message.Replace("<", "&lt;").Replace(">", "&gt;");
            Clients.Others.GetMessage(userName, message);
        }



        //채팅 사용자 목록저장
        private static List<ChatUserMaster> _chatUserList = new List<ChatUserMaster>();

        /// <summary>
        /// 그룹 채팅방 입장
        /// </summary>
        /// <param name="groupName">채팅방명</param>
        /// <param name="userName">닉네임</param>
        public Task EntryGroup(string groupName, string userName)
        {
            Task ts = Groups.Add(Context.ConnectionId, groupName);

            string userIPAddress = Context.Request.GetHttpContext().Request.ServerVariables["Remote_ADDR"].ToString();

            //IP차단 사용자 체크
            if (CheckBlockingTarget(groupName, userIPAddress, userName))
            {
                Clients.Caller.entryGroupMessage("관리자에 의해 요청 서비스가 거부되었습니다.", "IPDeny");
                ts = Groups.Remove(Context.ConnectionId, groupName);
                return ts;
            }

            ChatUserMaster userData = new ChatUserMaster();
            userData.ConnectionID = Context.ConnectionId;
            userData.ChatRoomName = groupName;
            userData.NickName = userName;
            userData.ConnectedDate = DateTime.Now;
            userData.IPAddress = userIPAddress;
            userData.ConnectedDate = DateTime.Now;

            db.ChatUserMaster.Add(userData);
            db.SaveChanges();

            _chatUserList.Add(userData);

            int userCnt = _chatUserList.Where(c => c.ChatRoomName == groupName).Count();

            string entryMsg1 = string.Format("{0}님으로 입장했습니다.", userName);
            Clients.Caller.entryGroupMessage(entryMsg1, userCnt);

            string entryMsg2 = string.Format("{0}님이 입장하셨습니다.", userName);
            Clients.OthersInGroup(groupName).entryGroupMessage(entryMsg2, userCnt);

            return ts;
        }


        /// <summary>
        /// IP차단 대상 여부체크
        /// </summary>
        /// <param name="roomName">채팅방명</param>
        /// <param name="userIPAddress">아이피주소</param>
        /// <param name="nickName">대화명</param>
        /// <returns>결과</returns>
        public bool CheckBlockingTarget(string roomName, string userIPAddress, string nickName)
        {
            bool result = true;
            DateTime todate = new DateTime();

            List<ChattingBlocking> list = null;
            list = db.ChattingBlocking.AsEnumerable<ChattingBlocking>().Where(s => s.ChatRoomName == roomName && s.IPAddress == userIPAddress && s.BlockingEndDate >= todate).ToList<ChattingBlocking>();

            if (list == null)
            {
                result = false;
            }
            else
            {
                if (list.Count == 0)
                {
                    result = false;
                }
            }
            return result;
        }





        /// <summary>
        /// 채팅방 접속자 목록 반환
        /// </summary>
        /// <param name="chatGroupName">채팅방명</param>
        public void CheckUserList(string groupName)
        {
            var users = _chatUserList.Where(c => c.ChatRoomName == groupName).ToList();
            Clients.Caller.getUserList(users);
        }



        // 아이피 블로킹 및 강퇴처리
        public void IpBlocking(string jsonUserList)
        {
            ChatBlockingInfo blocking = JsonConvert.DeserializeObject<ChatBlockingInfo>(jsonUserList);
            foreach (BlockingUserInfo user in blocking.NickNames)
            {
                ChatUserMaster chatUser = null;
                chatUser = _chatUserList.Where(c => c.ChatRoomName == user.RoomName && c.NickName == user.NickName).FirstOrDefault();
                if (chatUser != null)
                {
                    //IP차단정보 저장
                    ChattingBlocking blockingData = new ChattingBlocking();
                    blockingData.BlockingDate = DateTime.Now;
                    blockingData.BlockingEndDate = user.BlockingType == "D" ? DateTime.Now.AddDays(1) : DateTime.Now.AddMonths(1);
                    blockingData.ChatRoomName = chatUser.ChatRoomName;
                    blockingData.IPAddress = chatUser.IPAddress;
                    blockingData.UserNickName = chatUser.NickName;
                    blockingData.BlockingType = user.BlockingType;
                    db.ChattingBlocking.Add(blockingData);
                    db.SaveChanges();

                    //사용자 채팅 강퇴 아웃처리
                    UserConnectionOut(user.RoomName, user.NickName, "님이 강퇴처리 되었습니다.");
                }
            }
        }


        // 사용자 채팅 강퇴아웃
        private void UserConnectionOut(string roomName, string nickName, string msg)
        {
            ChatUserMaster user = _chatUserList.Where(c => c.ChatRoomName == roomName && c.NickName == nickName).FirstOrDefault();
            if (user != null)
            {
                //사용자목록에서 삭제
                _chatUserList.Remove(user);
                //퇴장메시지 발송
                Clients.Group(user.ChatRoomName).goodByDeny(user.NickName + msg, _chatUserList.Where(c => c.ChatRoomName == user.ChatRoomName).Count());
                //그룹에서 사용자 삭제
                Groups.Remove(user.ConnectionID, user.ChatRoomName);
            }
        }





        // 퇴장하기
        public void ChatExit()
        {
            UserConnectionOut();
        }

        /// <summary>
        /// 사용자 채팅 아웃
        /// </summary>
        private void UserConnectionOut()
        {
            ChatUserMaster user = _chatUserList.Where(c => c.ConnectionID == Context.ConnectionId).FirstOrDefault();
            if (user != null)
            {
                //사용자목록에서 삭제
                _chatUserList.Remove(user);

                //퇴장메시지 발송
                Clients.OthersInGroup(user.ChatRoomName).goodByMsg(user.NickName+ " 님이 퇴장하셨습니다.", _chatUserList.Where(c => c.ChatRoomName == user.ChatRoomName).Count());

                //그룹에서 사용자 삭제
                Groups.Remove(Context.ConnectionId, user.ChatRoomName);
            }
        }


    



        /// <summary>
        /// 사용자 커넥션 발생시
        /// </summary>
        /// <returns></returns>
        public override Task OnConnected()
        {
            return base.OnConnected();
        }

        /// <summary>
        /// 사용자 연결이 끊어질때(브라우저 닫기/탭닫기)
        /// </summary>
        /// <returns></returns>
        public override Task OnDisconnected(bool stopCalled)
        {
            var user = _chatUserList.Where(c => c.ConnectionID == Context.ConnectionId).FirstOrDefault();
            if(user != null)
            {
                UserConnectionOut(user.ChatRoomName, user.NickName, " 님이 퇴장하셨습니다.");
            }
            return base.OnDisconnected(stopCalled);
        }

        /// <summary>
        /// 사용자 재연결 발생시
        /// </summary>
        /// <returns></returns>
        public override Task OnReconnected()
        {
            return base.OnReconnected();
        }

    }
}